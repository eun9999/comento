﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using Microsoft.Win32;
using System.Security;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace GridWebBrowser
{
    public partial class WebBrowser : UserControl
    {
        private const string InternetExplorerRootKey = @"Software\Microsoft\Internet Explorer";
        private const string BrowerEmulationKey = InternetExplorerRootKey + @"\Main\FeatureControl\FEATURE_BROWSER_EMULATION";
        private enum BrowerEmulationVersion
        {
            Default = 0,
            Version7 = 7000,
            Version8 = 8000,
            Version8Standards = 8888,
            Version9 = 9000,
            Version9Standards = 9999,
            Version10 = 10000,
            Version10Standards = 10001,
            Version11 = 11000,
            Version11Edge = 11001
        }
        //[DllImport("wininet.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto, SetLastError = true)]
        //public static extern bool InternetSetOption(int hInternet, int dwOption, IntPtr lpBuffer, int dwBufferLength);




        private String m_Address = null;
        private int m_TimeoutSec = 20;
        private Dictionary<string, Size> docSizes = new Dictionary<string, Size>();
        private bool timerEnabled = false;
        private int idx;

        public delegate void CustomEventHandler(object sender, WebBrowserNavigatedEventArgs e);
        public event CustomEventHandler GoURLEnded;


        public WebBrowser(int idx)
        {
            this.idx = idx;
            InitializeComponent();
        }

        public int Index
        {
            get { return this.idx; }
        }

        private void WebBrowser_Load(object sender, EventArgs e)
        {
            SetBrowserEmulationVersion();

            tblWB.Dock = DockStyle.Fill;

            wbMain.ScriptErrorsSuppressed = true;
            timer.Enabled = true;
            
            SHDocVw.WebBrowser axBrowser = (SHDocVw.WebBrowser)this.wbMain.ActiveXInstance;
            axBrowser.NavigateError += new SHDocVw.DWebBrowserEvents2_NavigateErrorEventHandler(axBrowser_NavigateError);
        }



        #region 현재 설치되어 있는 IE 버전 취득
        private int GetIEVersion()
        {
            int result = 0;
            try
            {
                RegistryKey key = Registry.LocalMachine.OpenSubKey(InternetExplorerRootKey);
                if (key != null)
                {
                    object value = key.GetValue("svcVersion", null) ?? key.GetValue("Version", null);
                    if (value != null)
                    {
                        string version = value.ToString();
                        int separator = version.IndexOf('.');
                        if (separator != -1)
                        {
                            int.TryParse(version.Substring(0, separator), out result);
                        }
                    }
                }

            }
            catch (SecurityException)
            {
            }
            catch (UnauthorizedAccessException)
            {
            }
            return result;
        }

        private BrowerEmulationVersion GetBrowerEmulationVersion()
        {
            BrowerEmulationVersion result = BrowerEmulationVersion.Default;
            try
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey(BrowerEmulationKey, true);
                if (key != null)
                {
                    string programName = Path.GetFileName(Environment.GetCommandLineArgs()[0]);
                    object value = key.GetValue(programName, null);
                    if (value != null)
                    {
                        result = (BrowerEmulationVersion)Convert.ToInt32(value);
                    }
                }
            }
            catch (SecurityException)
            {
            }
            catch (UnauthorizedAccessException)
            {
            }
            return result;
        }

        private bool SetBrowserEmulationVersion(BrowerEmulationVersion browerEmulationVersion)
        {
            bool result = false;
            try
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey(BrowerEmulationKey, true);
                if (key != null)
                {
                    string programName = Path.GetFileName(Environment.GetCommandLineArgs()[0]);
                    if (browerEmulationVersion != BrowerEmulationVersion.Default)
                    {
                        key.SetValue(programName, (int)browerEmulationVersion, RegistryValueKind.DWord);
                    }
                    else
                    {
                        key.DeleteValue(programName, false);
                    }
                    result = true;
                }
            }
            catch (SecurityException)
            {
            }
            catch (UnauthorizedAccessException)
            {
            }
            return result;
        }

        private bool SetBrowserEmulationVersion()
        {
            int ieVersion = GetIEVersion();
            BrowerEmulationVersion emulationCode;

            if (ieVersion >= 11)
            {
                emulationCode = BrowerEmulationVersion.Version11;
            }
            else
            {
                switch (ieVersion)
                {
                    case 10:
                        emulationCode = BrowerEmulationVersion.Version10;
                        break;
                    case 9:
                        emulationCode = BrowerEmulationVersion.Version9;
                        break;
                    case 8:
                        emulationCode = BrowerEmulationVersion.Version8;
                        break;
                    default:
                        emulationCode = BrowerEmulationVersion.Version7;
                        break;
                }
            }
            return SetBrowserEmulationVersion(emulationCode);
        }

        //private unsafe void SuppressWininetBehavior()
        //{
        //    int option = (int)3;
        //    int* optionPrt = &option;

        //    bool success = InternetSetOption(0, 81, new IntPtr(optionPrt), sizeof(int));
        //    if (!success)
        //    {
        //        MessageBox.Show("SuppressWininetBehavior Fail");
        //    }
        //}
        #endregion

        

        void axBrowser_NavigateError(object pDisp, ref object URL, ref object Frame, ref object StatusCode, ref bool Cancel)
        {
            Console.WriteLine(URL + "ERROR >> HTTP Code : " + StatusCode.ToString());
            
            if (StatusCode.ToString() == "-2146697211")
            {
                lblError.Text = "잘못된 도메인";
            }
            else 
            {
                lblError.Text = StatusCode.ToString();
            }
            
            lblError.Refresh();
            lblError.BringToFront();
            Application.DoEvents();
        }

        public void GoURL()
        {
            this.GoURL(this.m_Address);
        }

        public void GoURL(String address)
        {
            if (address == null || "".Equals(address.Trim())) return;
            IngDisplay(true);
            m_Address = address;

            if (String.IsNullOrEmpty(m_Address) || m_Address.Trim().Equals("about:blank"))
            {
                IngDisplay(false);
            }
            else
            {
                // URL이 존재할 경우에만
                if (!m_Address.StartsWith("http://") && !m_Address.StartsWith("https://"))
                {
                    m_Address = "http://" + m_Address;
                }
                try
                {
                    Console.WriteLine("GoURL() <<Navigate Start !!>> [m_Address: " + m_Address + "]");
                    wbMain.Navigate(new Uri(m_Address));
                    int cnt = 0;
                    while (wbMain.ReadyState != WebBrowserReadyState.Complete && wbMain.ReadyState != WebBrowserReadyState.Uninitialized)
                    {
                        cnt++;
                        Thread.Sleep(100);
                        Application.DoEvents();
                        if ((cnt/10) > this.m_TimeoutSec) break;
                    }
                    Console.WriteLine("GoURL() <<Navigate END !!!!>> [m_Address: " + m_Address + "], [wbMain.ReadyState: " + wbMain.ReadyState + "]");
                }
                catch (Exception e)
                {
                    Console.WriteLine("GoURL() Exception [m_Address: " + m_Address+ ", Exception: " + e + "]");
                }
                finally
                {
                    Thread.Sleep(500);
                    IngDisplay(false);

                    // Single 모드일때만 작동 (멀티모드에서는 GoURLEnded이 Null 임)
                    if (GoURLEnded != null && !m_Address.StartsWith("http://") && !m_Address.StartsWith("https://"))
                    {
                        WebBrowserNavigatedEventArgs e = new WebBrowserNavigatedEventArgs(new Uri(m_Address));
                        GoURLEnded(this, e);        // Event 발생
                    }
                }
            }
        }

        private void IngDisplay(bool ing)
        {
            try
            {
                if (ing)
                {
                    lblTitle.ForeColor = Color.Blue;
                    lblTime.ForeColor = Color.Blue;
                    lblTitle.Text += " ...";
                    this.BackColor = Color.AliceBlue;
                }
                else
                {
                    lblTitle.ForeColor = Color.Black;
                    lblTime.ForeColor = Color.Black;
                    lblTitle.Text = lblTitle.Text.Replace(" ...", "");
                    this.BackColor = Color.White;
                }
                lblTitle.Refresh();
                Application.DoEvents();
            }
            catch (Exception) { }
        }

        public int RefreshSecond
        {
            get
            {
                return timer.Interval / 1000;
            }
        }

        public void SetRefreshSecond(int sec)
        {
            timer.Interval = sec * 1000;
        }


        public bool TimerEnabled
        {
            get
            {
                return this.timerEnabled;
            }
        }

        public void SetTimerEnabled(bool enabled)
        {
            this.timerEnabled = enabled;
            timer.Enabled = this.timerEnabled;
        }

        public int TimeOutSecond
        {
            get
            {
                return this.m_TimeoutSec;
            }
            set
            {
                if (TimeOutSecond < 1)
                    this.m_TimeoutSec = 10;
                else if (TimeOutSecond > 180)
                    this.m_TimeoutSec = 180;
                else
                    this.m_TimeoutSec = TimeOutSecond;
            }
        }

        private void wbMain_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            Console.WriteLine("wbMain_DocumentCompleted (" + wbMain.Url + ") -> " + e.Url);
            
            //HtmlRemoveScript("Touch");
            HtmlRemoveObject();

            lblTime.Text = DateTime.Now.ToString("HH:mm:ss"); 
            ResizeDocument();
        }

        private void wbMain_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            Console.WriteLine("wbMain_Navigated (" + wbMain.Url + ") -> " + e.Url);
            HtmlAlertDisable();
        }

        private void wbMain_NewWindow(object sender, CancelEventArgs e)
        {
            e.Cancel = true;
        }

        private void HtmlAlertDisable()
        {
            HtmlElement head = wbMain.Document.GetElementsByTagName("head")[0];
            if (head != null)
            {
                HtmlElement script = wbMain.Document.CreateElement("script");
                script.SetAttribute("type", "text/javascript");
                script.SetAttribute("text", "window.alert = function(){}; window.confirm = function(){}; ");
                head.AppendChild(script);
            }
        }

        private void HtmlRemoveScript(string findStr)
        {
            HtmlElementCollection scripts = wbMain.Document.GetElementsByTagName("script");
            foreach (HtmlElement script in scripts)
            {
                if (script.GetAttribute("OuterHtml").IndexOf(findStr) > 0) script.SetAttribute("OuterHtml", "");
            }
        }

        private void HtmlRemoveObject()
        {
            HtmlElementCollection objs = wbMain.Document.GetElementsByTagName("object");
            foreach (HtmlElement obj in objs)
            {
                obj.SetAttribute("OuterHtml", "");
            }
        }

        private void ResizeDocument()
        {
            try
            {
                if (wbMain.ReadyState == WebBrowserReadyState.Complete)
                {
                    string url = wbMain.Url.ToString();

                    double wbWidth = wbMain.Width;
                    double wbHeight = wbMain.Height;

                    if (wbMain.Document.Body != null)
                    {
                        // HTML W,H 구하기
                        double docWidth = wbMain.Document.Body.ScrollRectangle.Width;
                        double docHeight = wbMain.Document.Body.ScrollRectangle.Height;

                        if (docSizes.ContainsKey(url))
                        {
                            docWidth = docSizes[url].Width;
                            docHeight = docSizes[url].Height;
                        }
                        else
                        {
                            docSizes.Add(url, wbMain.Document.Body.ScrollRectangle.Size);
                        }

                        Console.WriteLine(wbMain.Url + " -> 브라우져(W,H) : (" + wbWidth + ", " + wbHeight + ") ==> HTML(W,H) : (" + docWidth + ", " + docHeight + ")");

                        if (docHeight > wbHeight)
                        {
                            // HTML이 브라우져보다 클경우
                            double factor = Math.Round(Math.Min(wbWidth / docWidth, wbHeight / docHeight), 2) * 100;

                            int zoomFactor = Int16.Parse(factor.ToString());
                            ((SHDocVw.WebBrowser)wbMain.ActiveXInstance).ExecWB(SHDocVw.OLECMDID.OLECMDID_OPTICAL_ZOOM,
                                SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DONTPROMPTUSER, zoomFactor, IntPtr.Zero);

                            Console.WriteLine("[ZOOM] " + wbMain.Url + " --> " + zoomFactor + "%");
                        }
                        else if (docWidth == 0 || docHeight == 0)
                        {
                            // 하나라도 브라우져 사이즈가 0이면 그낭 40% 처리 
                            ((SHDocVw.WebBrowser)wbMain.ActiveXInstance).ExecWB(SHDocVw.OLECMDID.OLECMDID_OPTICAL_ZOOM,
                                SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DONTPROMPTUSER, 40, IntPtr.Zero);

                            Console.WriteLine("[ZOOM] " + wbMain.Url + " --> Force 40%");
                        }
                    }
                }

                // Error 라벨 위치 조정
                lblError.Top = this.Height - lblError.Height - 10;
                lblError.Left = 5;
            }
            catch (Exception) { }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            timer.Enabled = false;
            Console.WriteLine("WB[" + this.idx + "] timer_Tick : wbMain.IsBusy --> " + wbMain.IsBusy + ", wbMain.ReadyState --> " + wbMain.ReadyState.ToString());
            
            if (this.timerEnabled)
            {
                if (wbMain.ReadyState == WebBrowserReadyState.Uninitialized || wbMain.ReadyState == WebBrowserReadyState.Complete)
                {
                    this.GoURL(m_Address);
                    Console.WriteLine("WB[" + this.idx + "] timer_Tick : GoURL(m_Address) --> " + m_Address + ", Done.");
                }
            }
            timer.Enabled = true;
        }

        private void wbMain_SizeChanged(object sender, EventArgs e)
        {
            ResizeDocument();
        }

        public string Title
        {
            set
            {
                lblTitle.Text = value;
            }
            get
            {
                return lblTitle.Text;
            }
        }

        public string Address
        {
            get
            {
                return this.m_Address;
            }
        }

        public void SetAddress(string address)
        {
            this.m_Address = address;
        }

        private void wbMain_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            Console.WriteLine("wbMain_Navigating (" + wbMain.Url + ") -> " + e.Url);

            lblError.Text = "";
            lblError.Refresh();
        }

        private void itemReload_Click(object sender, EventArgs e)
        {
            this.GoURL();
        }

        private void itemOpenIE_Click(object sender, EventArgs e)
        {
            if (m_Address == null || "".Equals(m_Address.Trim())) return;
            try
            {
                Process.Start("iexplore.exe", m_Address);
            }
            catch (Exception) { }
        }

        private void itemShowSetting_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(" - Title: " + this.Title);
            sb.AppendLine(" - Address: " + this.Address);
            sb.AppendLine(" - RefreshSecond: " + this.RefreshSecond + "초");
            sb.AppendLine(" - TimeOutSecond: " + this.TimeOutSecond + "초");

            MessageBox.Show(sb.ToString(), "WebBrowser[" + idx + "] 설정정보");
        }
    }
}
