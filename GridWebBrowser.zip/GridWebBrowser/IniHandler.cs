﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace GridWebBrowser
{
    class IniHandler
    {
        #region [ INI관련 Win32 API 선언부 ]
        [DllImport("kernel32")]
        private static extern bool WritePrivateProfileString(string lpAppName, string lpKeyName, string lpString, string lpFileName);

        [DllImport("kernel32")]
        private static extern uint GetPrivateProfileInt(string lpAppName, string lpKeyName, int nDefault, string lpFileName);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, int nSize, string lpFileName);
        #endregion

        public static bool Write(string Section, string Key, string Value)
        {
            return WritePrivateProfileString(Section, Key, Value, GetIniFile());
        }

        public static string ReadString(string Section, string Key)
        {
            return ReadString(Section, Key, "");
        }

        public static string ReadString(string Section, string Key, string Default)
        {
            StringBuilder ret = new StringBuilder(512);
            GetPrivateProfileString(Section, Key, "", ret, 512, GetIniFile());

            string Value = ret.ToString();
            if (Value.Equals("") && !Default.Equals("") && !Value.Equals(Default))
            {
                Write(Section, Key, Default);
                Value = Default;
            }

            return Value;
        }

        public static int ReadInt(string Section, string Key)
        {
            return (int)GetPrivateProfileInt(Section, Key, 0, GetIniFile());
        }

        public static int ReadInt(string Section, string Key, int Default)
        {
            int ret = ReadInt(Section, Key);

            if (ret == 0 && Default != 0)
            {
                Write(Section, Key, Default.ToString());
                ret = Default;
            }

            return ret;
        }

        public static double ReadDouble(string Section, string Key)
        {
            return double.Parse(ReadString(Section, Key));
        }

        public static double ReadDouble(string Section, string Key, double Default)
        {
            double ret = ReadDouble(Section, Key);
            if (ret == 0d && Default != 0d)
            {
                Write(Section, Key, Default.ToString());
                ret = Default;
            }

            return ret;
        }

        public static float ReadFloat(string Section, string Key)
        {
            return float.Parse(ReadString(Section, Key));
        }

        public static float ReadFloat(string Section, string Key, float Default)
        {
            float ret = ReadFloat(Section, Key);
            if (ret == 0f && Default != 0f)
            {
                Write(Section, Key, Default.ToString());
                ret = Default;
            }

            return ret;
        }

        public static short ReadShort(string Section, string Key, short Default)
        {
            short ret = (short)GetPrivateProfileInt(Section, Key, 0, GetIniFile());

            if (ret == 0 && Default != 0)
            {
                Write(Section, Key, Default.ToString());
                ret = Default;
            }

            return ret;
        }
        public static bool ReadBool(string Section, string Key)
        {
            return ReadBool(Section, Key, false);
        }

        public static bool ReadBool(string Section, string Key, bool Default)
        {
            string str = ReadString(Section, Key).ToLower();
            if (str.Equals("true"))
            {
                return true;
            }
            else if (str.Equals("false"))
            {
                return false;
            }
            else
            {
                Write(Section, Key, Default.ToString().ToLower());
                return Default;
            }
        }

        private static string GetIniFile()
        {
            StringBuilder fb = new StringBuilder();
            fb.AppendFormat(@"{0}\{1}"
                , EXEDIR
                , "environment.ini"
            );
            return fb.ToString();
        }

        public static string EXEDIR
        {
            get
            {
                return Application.ExecutablePath.Substring(0, Application.ExecutablePath.LastIndexOf(@"\"));
            }
        }
    }
}
