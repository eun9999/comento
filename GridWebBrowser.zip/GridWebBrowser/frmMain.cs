﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Threading;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace GridWebBrowser
{
    public partial class frmMain : Form
    {
        private WebBrowser[] webBrowsers = null;
        private string mode = null;

        // System Menu 관련 정의
        public const Int32 WM_SYSCOMMAND = 0x112;
        public const Int32 MF_SEPARATOR = 0x800;
        public const Int32 MF_STRING = 0x0;
        public const Int32 IDM_OPENENV = 1000;
        public const Int32 IDM_ABOUT = 2000;

        [DllImport("user32.dll")]
        private static extern bool AppendMenu(IntPtr hMenu, Int32 wFlags, Int32 wldNewItem, string lpNewItem);
        [DllImport("user32.dll")]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_SYSCOMMAND)
            {
                switch (m.WParam.ToInt32())
                {
                    case IDM_OPENENV:
                        Process.Start("notepad.exe", "environment.ini");
                        return;
                    case IDM_ABOUT:
                        frmAboutBox about = new frmAboutBox();
                        about.ShowDialog();
                        return;
                    default:
                        break;
                }
            }
            base.WndProc(ref m);
        }

        public frmMain()
        {
#if DEBUG
            this.WindowState = FormWindowState.Normal;
#else
            this.WindowState = FormWindowState.Maximized;
#endif
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // System Menu 관련
            IntPtr sysMenuHandle = GetSystemMenu(this.Handle, false);
            AppendMenu(sysMenuHandle, MF_SEPARATOR, 0, string.Empty);
            AppendMenu(sysMenuHandle, MF_STRING, IDM_OPENENV, "Open Environment File ...");
            AppendMenu(sysMenuHandle, MF_STRING, IDM_ABOUT, "About GridWebBrowser ...");


            // 최초 Grid 셋팅
            int Row = IniHandler.ReadInt("GENERAL", "ROW", 2);
            int Col = IniHandler.ReadInt("GENERAL", "COL", 3);

            mode = IniHandler.ReadString("GENERAL", "MODE", "M");

            this.Text += " - " + Assembly.GetExecutingAssembly().GetName().Version + ("S".Equals(mode) ? " [단일모드]" : " [멀티모드]");
            
            GenGrid(Row, Col);
        }

        private void frmMain_Shown(object sender, EventArgs e)
        {
            Navigate();
        }

        private void GenGrid(int Row, int Col)
        {
            tblMain.Dock = DockStyle.Fill;
            tblMain.RowCount = Row;
            tblMain.ColumnCount = Col;

            tblMain.RowStyles.Clear();
            tblMain.ColumnStyles.Clear();
            
            webBrowsers = new WebBrowser[Row * Col];
            int idx = 0;
            for (int i = 0; i < Row; i++)
            {
                tblMain.RowStyles.Add(new RowStyle(SizeType.Percent, 100 / Row));

                for (int j = 0; j < Col; j++)
                {
                    if (i == 0)
                    {
                        tblMain.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100 / Col));
                    }
                    webBrowsers[idx] = new WebBrowser(idx);
                    tblMain.Controls.Add(webBrowsers[idx]);
                    tblMain.SetRow(webBrowsers[idx], i );
                    tblMain.SetColumn(webBrowsers[idx], j );
                    webBrowsers[idx].Dock = DockStyle.Fill;
                    // Single 모드일때만 작동 필요
                    if ("S".Equals(mode)) webBrowsers[idx].GoURLEnded += new WebBrowser.CustomEventHandler(onGoURLEnded);
                    idx++;
                }
            }
        }

        private object lockObj = new object();
        private void onGoURLEnded(object sender, WebBrowserNavigatedEventArgs e)
        {
            lock (lockObj)
            {
                if (e.Url.OriginalString.StartsWith("http"))
                {
                    ((WebBrowser)sender).SetTimerEnabled(false);

                    int currIdx = ((WebBrowser)sender).Index;

                    int idx = currIdx + 1;

                    do
                    {
                        if (idx > webBrowsers.Length - 1) idx = 0;     // 마지막 까지 도달한 경우 처음부터
                        if (String.IsNullOrEmpty(IniHandler.ReadString("WB" + (idx + 1), "URL")))
                        {
                            idx++;      // 1증가
                            Console.WriteLine("onGoURLEnded ---> WebBrowser [Curr idx : " + currIdx + ", Next Index + (1) : " + idx + "]");
                        }
                        else
                        {
                            webBrowsers[idx].SetTimerEnabled(true);
                            Console.WriteLine("onGoURLEnded ---> WebBrowser [Curr idx : " + currIdx + ", Next Index : " + idx + "] Timer Enabled (" + webBrowsers[idx].RefreshSecond + "초)");
                            break;
                        }
                        if (currIdx == idx)
                        {
                            Console.WriteLine("onGoURLEnded ---> WebBrowser [Curr idx : " + currIdx + ", Next Index  : " + idx + "] 한바뀌 다 돔 EXIT");
                            break;      // 한바뀌 다돈 경우 exit
                        }
                    } while (true);
                }
            }
        }

        private void Navigate()
        {
            int idx = 1;
            int startGoIdx = -1;
            for (int i = 0; i < tblMain.RowCount; i++)
            {
                for (int j = 0; j < tblMain.ColumnCount; j++)
                {
                    string url = IniHandler.ReadString("WB" + idx, "URL").Trim();
                    if (!String.IsNullOrEmpty(url))
                    {
                        webBrowsers[idx - 1].SetTimerEnabled(!"S".Equals(mode));      // S - false , M - true

                        webBrowsers[idx - 1].Title = IniHandler.ReadString("WB" + idx, "TITLE", "Site Name");
                        // REFRESH_SEC는 최소 10이상으로...
                        if (IniHandler.ReadInt("WB" + idx, "REFRESH_SEC") < 10) IniHandler.Write("WB" + idx, "REFRESH_SEC", "10");
                        webBrowsers[idx - 1].SetRefreshSecond(IniHandler.ReadInt("WB" + idx, "REFRESH_SEC", 10));

                        if ("S".Equals(mode))
                        {
                            // Single Mode
                            webBrowsers[idx - 1].SetAddress(IniHandler.ReadString("WB" + idx, "URL"));
                            if (startGoIdx == -1) startGoIdx = idx - 1;
                        }
                        else
                        {
                            // Multi Mode
                            webBrowsers[idx - 1].GoURL(IniHandler.ReadString("WB" + idx, "URL"));
                            for (int cnt = 0; cnt < 5; cnt++)
                            {
                                Thread.Sleep(100);
                                Application.DoEvents();
                            }
                        }
                    }
                    idx++;
                    Application.DoEvents();
                }
                Application.DoEvents();
            }
            if (startGoIdx > -1) webBrowsers[startGoIdx].GoURL();

            Console.WriteLine("Navigate() Ended");
        }


    }
}
